package main

import (
	"Judger/judger"
	"fmt"
	"log"
	"net/http"
	"net/rpc"
	"os"
)

func init() {
	os.Mkdir(judger.Dir, 777)
}

type Judge int

func (c *Judge) Judging(args map[string]interface{}, result *int) error {

	*result = judger.JudgeCode(args["code"].(string), args["username"].(string), args["problem"].(int))
	return nil

}

func main() {

	rpc.Register(new(Judge))
	rpc.HandleHTTP()

	fmt.Println("############################################################")
	fmt.Println("#       This Judger RPC is working on localhost:65534       #")
	fmt.Println("############################################################")

	if err := http.ListenAndServe(":65534", nil); err != nil {
		log.Fatalf("Error serve")
	}

}
