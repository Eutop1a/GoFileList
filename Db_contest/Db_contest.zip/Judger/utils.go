package main

import (
	"Judger/judger"
	"io/ioutil"
	"strconv"
)

func GetProblems() []int {

	fi, err := ioutil.ReadDir(judger.Dir)

	res := make([]int, 0)

	if err != nil {
		return res
	}

	for _, f := range fi {
		if f.IsDir() {
			num, err := strconv.Atoi(f.Name())

			if err != nil || f.Name()[0] == '0' {
				continue
			}

			res = append(res, num)
		}
	}

	return res

}
