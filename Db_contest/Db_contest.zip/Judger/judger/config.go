package judger

const (
	Dir = "D:\\MyOjProblems"
)
