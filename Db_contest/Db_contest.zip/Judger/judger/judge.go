package judger

import (
	"errors"
	"fmt"
	"io/ioutil"
	"os"
	"os/exec"
	"strconv"
	"strings"
)

func JudgeCode(code string, username string, problemNum int) int {

	fmt.Println("Code:", code)
	fmt.Println("Username:", username)
	fmt.Println("ProblemNum:", problemNum)
	fmt.Println()

	err := CreateSourceFile(code, username, problemNum)
	if err != nil {
		return SystemError
	}

	path := Dir + "\\" + "Problem_" + strconv.Itoa(problemNum)
	file_name := strconv.Itoa(problemNum) + "_" + username

	if Complier(path, file_name) != nil {
		fmt.Println(path, file_name)
		return ComplierError
	} //编译错误

	defer os.Remove(Dir + "\\" + "Problem_" + strconv.Itoa(problemNum) + "\\" + file_name + ".cpp")
	defer os.Remove(Dir + "\\" + "Problem_" + strconv.Itoa(problemNum) + "\\" + file_name + ".exe")
	//删除文件

	if files, err := ioutil.ReadDir(path); err != nil {
		return SystemError //没有测试数据集，系统错误！
	} else {
		for _, fileInfo := range files {
			if fileInfo.IsDir() {
				continue
			}
			if strings.HasSuffix(fileInfo.Name(), ".in") {
				if !RunAndCompare(path+"\\"+file_name+".exe", path+"\\"+strings.ReplaceAll(fileInfo.Name(), ".in", ""), username) {
					return WrongAnswer
				}
			}
		}
	}

	return Accepted

}

func RunAndCompare(path string, dataPath string, username string) bool {

	c := fmt.Sprintf("/C %s < %s > %s", path, dataPath+".in", dataPath+"."+username+".out")
	cmd := exec.Command("cmd", strings.Split(c, " ")...)

	err := cmd.Run()
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr

	if err != nil {
		return false
	}

	defer os.Remove(dataPath + "." + username + ".out")
	return Compare(dataPath+".out", dataPath+"."+username+".out")

}

func CreateSourceFile(code, username string, problemNum int) error {

	path := Dir + "\\" + "Problem_" + strconv.Itoa(problemNum)
	fileName := strconv.Itoa(problemNum) + "_" + username
	problemFile, err := os.OpenFile(path+"\\"+fileName+".cpp", os.O_CREATE, 666)
	if err != nil {
		return err
	} //创建CPP文件

	succ, err := problemFile.WriteString(code)
	if succ != len(code) || err != nil {
		return errors.New("create Failed")
	} //写入CPP文件

	defer problemFile.Close()
	return nil

}
