package judger

import (
	"fmt"
	"io/ioutil"
	"os"
	"reflect"
)

func Compare(path_a string, path_b string) bool {

	file_a, err_a := os.OpenFile(path_a, os.O_RDWR, 777)
	file_b, err_b := os.OpenFile(path_b, os.O_RDWR, 777)
	defer file_a.Close()
	defer file_b.Close()

	if err_a != nil || err_b != nil {
		fmt.Println(err_a, err_b)
		return false
	}

	data_a, err_a := ioutil.ReadAll(file_a)
	data_b, err_b := ioutil.ReadAll(file_b)

	return reflect.DeepEqual(data_a, data_b)

}
