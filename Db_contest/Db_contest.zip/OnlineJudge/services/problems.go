package services

import (
	"OnlineJudge/dao/mysql"
	"OnlineJudge/dao/mysql/users"
	"OnlineJudge/models"
	"go.uber.org/zap"
	"net/http"
	"strconv"
)

type Problem struct {
	UserName string `form:"username" json:"username"`
	Id       string `form:"id" json:"id"`
	Title    string `form:"title" json:"title"`
	Lore     string `form:"lore" json:"lore"`
	Input    string `form:"input" json:"input"`
	Output   string `form:"output" json:"output"`
	Tips     string `form:"tips" json:"tips"`
}

// GetList 获取问题列表
// @Summary 获取问题列表
// @Description 获取所有问题的列表
// @Accept json
// @Produce json
// @Param username formData string true "要获取问题列表的用户名"
// @Success 200 {object} models._ResponseProblems "成功获取问题列表"
// @Failure 403 {object} models._ResponseMsg "Token 已超时"
// @Failure 500 {object} models._ResponseMsg "获取问题列表出错"
// @Router /list [post]
func (problem *Problem) GetList() (int, string, []models.Problems) {

	// 查询问题列表
	var datas []models.Problems
	result := mysql.Db.Find(&datas)

	if result.Error != nil {
		// 获取问题列表出错
		zap.L().Error("get list error", zap.Error(result.Error))

		return http.StatusInternalServerError, "get list error", nil

	} else {
		// 成功获取问题列表
		return http.StatusOK, "", datas
	}
}

// AddProblem 添加问题
// @Summary 添加问题
// @Description 通过管理员身份，使用表单数据添加新的问题，并返回操作结果
// @Accept json
// @Produce json
// @Param username formData string true "执行操作的管理员用户名"
// @Param id formData string true "问题ID"
// @Param title formData string true "问题标题"
// @Param lore formData string true "问题描述"
// @Param input formData string true "问题标准输入"
// @Param output formData string true "问题标准输出"
// @Param tips formData string true "问题提示"
// @Success 200 {object} models._ResponseAddProblems "成功添加问题"
// @Failure 403 {object} models._ResponseMsg "Token 已超时或用户非管理员"
// @Failure 403 {object} models._ResponseMsg "解析表单数据出错"
// @Router /problem/add [post]
func (problem *Problem) AddProblem() (int, string) {

	// 判断用户是否为管理员
	if !users.JudgeAdmin(problem.UserName) {

		return http.StatusForbidden, "Forbidden"
	}

	// 将问题添加到数据库
	ID, _ := strconv.Atoi(problem.Id)
	mysql.Db.Create(&models.ProblemList{
		ProblemID:          ID,
		ProblemTitle:       problem.Title,
		ProblemLore:        problem.Lore,
		ProblemStandardIn:  problem.Input,
		ProblemStandardOut: problem.Output,
		ProblemTips:        problem.Tips,
		Author:             problem.UserName,
	})

	mysql.Db.Create(&models.Problems{
		ProblemTitle: problem.Title,
		ProblemID:    ID,
		Author:       problem.UserName,
	})

	return http.StatusOK, "Ok"
}

// GetProblem 获取问题详情
// @Summary 获取问题详情
// @Description 通过问题ID和管理员身份，获取指定问题的详细信息
// @Accept json
// @Produce json
// @Param _ formData string true "执行操作的管理员用户名"
// @Param id path string true "要获取的问题ID"
// @Success 200 {object} models._ResponseQuestionDetail  "成功获取问题详情"
// @Failure 403 {object} models._ResponseMsg "Token 已超时"
// @Failure 403 {object} models._ResponseMsg "获取问题详情出错"
// @Router /problem/:id [post]
func (problem *Problem) GetProblem(id string) (int, string, models.ProblemList) {

	// 查询指定问题的详细信息
	var data models.ProblemList
	mysql.Db.First(&data, "problem_id = ?", id)
	if data.ProblemTitle == "" {
		// 获取问题详情出错
		zap.L().Error("get problem error")

		return http.StatusBadRequest, "get problem error", models.ProblemList{}
	}
	return http.StatusOK, "", data
}
