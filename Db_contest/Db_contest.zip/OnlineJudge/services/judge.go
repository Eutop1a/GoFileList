package services

import (
	"fmt"
	"github.com/gin-gonic/gin"
	"net/http"
	"net/rpc"
)

type Judge struct {
	UserName string `form:"username" json:"username"`
	Problem  int    `form:"problem" json:"problem"`
	Code     string `form:"code" json:"code"`
}

const (
	Accepted      = 1000
	WrongAnswer   = 1001
	ComplierError = 1002
	TimeLimited   = 1003
	RuntimeError  = 1004
	MemoryLimited = 1005
	SystemError   = 1010
)

var flag = map[int]string{
	1000: "Accepted",
	1001: "WrongAnswer",
	1002: "ComplierError",
	1003: "TimeLimited",
	1004: "RuntimeError",
	1005: "MemoryLimited",
	1010: "SystemError",
}

// JudgeCode 代码评测
// @Summary 代码评测
// @Description 通过用户身份、问题ID和代码内容，进行代码评测，并返回评测结果
// @Accept json
// @Produce json
// @Param username formData string true "执行操作的用户名"
// @Param problem formData integer true "要评测的问题ID"
// @Param code formData string true "要评测的代码内容"
// @Success 200 {object} models._ResponseMsg "成功进行代码评测"
// @Failure 403 {object} models._ResponseMsg "Token 已超时"
// @Router /judge [post]
func (judge *Judge) JudgeCode() (int, string) {
	// 从请求中获取执行操作的用户名
	username := judge.UserName

	// 获取要评测的问题ID和代码内容
	type RequestData struct {
		Problem int    `json:"problem"`
		Code    string `json:"code"`
	}

	code := judge.Code
	problem := judge.Problem

	// 连接 RPC 服务器进行代码评测
	client, _ := rpc.DialHTTP("tcp", "localhost:65534")
	defer client.Close()

	var res int
	Go := client.Go("Judge.Judging", gin.H{
		"code":     code,
		"username": username,
		"problem":  problem,
	}, &res, nil)

	<-Go.Done
	fmt.Println("res=", res)
	//// 如果评测结果为 1010，返回状态码 403
	if res == 1010 {
		return http.StatusInternalServerError, ""
	}
	return http.StatusOK, flag[res]
}
