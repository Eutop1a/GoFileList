package mysql

const (
	users_info   = "users"
	user_solveds = "user_solveds"
	problem_list = "problem_lists"
)
